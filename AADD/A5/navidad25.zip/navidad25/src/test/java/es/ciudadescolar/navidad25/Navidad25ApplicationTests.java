package es.ciudadescolar.navidad25;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Navidad25ApplicationTests {

	@Test
	void contextLoads() {
	}

}
