package es.ciudadescolar.util;

public class TextManager {
    
}
